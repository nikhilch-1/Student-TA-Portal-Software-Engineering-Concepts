package com.gui.prototype.model;

import sun.security.util.Password;

public class Student {

    private int indexNum;
    private String name;
    private String email;
    private String sessionPassword;
    private int currentState;

    public Student(String name, String email) {
        this.name = name;
        this.email = email;
    }

    public void setCurrentState(int val) {
        this.currentState = val;
    }

    public void setSessionPassword(String p) {
        this.sessionPassword = p;
    }

    public String getSessionPassword() {
        return sessionPassword;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public int getCurrentState() { return currentState; }
}
