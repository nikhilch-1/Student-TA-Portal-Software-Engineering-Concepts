package com.gui.prototype.main;

import com.gui.prototype.viewer.UIBuilder;

public class Main {

    public static void main(String[] args) {
        System.out.println("Hello World");

        // Calling the UI to be loaded
        UIBuilder builder = new UIBuilder();
        builder.initialize();
    }

}
