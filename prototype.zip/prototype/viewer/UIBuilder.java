package com.gui.prototype.viewer;

import com.gui.prototype.model.CustomQueue;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.text.TableView;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.GridLayout;
import java.util.ArrayList;
import com.gui.prototype.model.Student;
import com.gui.prototype.model.GUITableModel;
import java.awt.Component;
import java.awt.Color;
import javax.swing.table.TableCellRenderer;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.border.*;
import java.util.Random;

public class UIBuilder {
    /* swing component */
    private JFrame frame;
    private JPanel Menu;
    private JTable studentQ;
    private JButton AddButton;
    private JButton RemoveButton;
    private JButton Pause;
    private JButton UnPause;
    private JLabel messageBox;

    /* event handler */
    private AddListener button_handler;
    private RemoveListener remove_handler;
    private PauseListener pause_handler;
    private UnpauseListener unpause_handler;

    /*  -1 when no row is selected */
    int selected_row; 

    /* utility */
    private void check_queue_empty(){
        if(studentQ.getRowCount() == 0){
            messageBox.setText("Queue empty!");
            messageBox.setForeground(Color.red);
        }
    }

    private void show_message(String msg, Color color){
        messageBox.setText(msg);
        messageBox.setForeground(color);
    }

    // Zhang
    public void initialize() {
        /* initialize private variable */
        frame = new JFrame();
        button_handler = new AddListener();
        remove_handler = new RemoveListener();
        pause_handler = new PauseListener();
        unpause_handler = new UnpauseListener();
        // focus_handler = new MyFocusListener();
        // cancel_selection = new CancelSelection();
        selected_row = -1;

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Menu = new JPanel();
        Menu.setBounds(0, 0, 600, 130);

        // Buttons
        AddButton = new JButton("Add");
        AddButton.setBounds(0, 30, 50, 50);
        AddButton.addActionListener(button_handler);
        Menu.add(AddButton);

        RemoveButton = new JButton("Remove");
        RemoveButton.addActionListener(remove_handler);
        Menu.add(RemoveButton);

        Pause = new JButton("Pause");
        Pause.addActionListener(pause_handler);
        Menu.add(Pause);

        UnPause = new JButton("Unpause");
        UnPause.addActionListener(unpause_handler);
        Menu.add(UnPause);

        Menu.setLayout(new FlowLayout(FlowLayout.LEADING,20,20));
        // maybe not a good idea, but it's a solution!
        Menu.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                AddButton.setEnabled(true);
                RemoveButton.setEnabled(false);
                Pause.setEnabled(false);
                UnPause.setEnabled(false);
                studentQ.clearSelection();
                selected_row = -1;
            }
        });

        // Default Entries
        int rand = new Random().nextInt(4);
        for(int i = 0; i < rand; i++){
            CustomQueue.addStudent("Student "+(i+i), "s"+(1+i)+"@buffalo.edu", "12345");
        }

        ArrayList<Student> students = CustomQueue.getAllEntries();

        // Table Model to modify rows as per the operations
        GUITableModel studModel = new GUITableModel(students);

        studentQ = new JTable(studModel){
            @Override
            public Component prepareRenderer(
                TableCellRenderer renderer, int row, int column)
            {   
                // rendering the background color on selection
                Component c = super.prepareRenderer(renderer, row, column);

                if (isRowSelected(row)){
                    c.setForeground(Color.white);
                    c.setBackground(Color.blue.darker());
                }else{
                    c.setForeground(Color.black);
                    c.setBackground(((GUITableModel)this.getModel()).GetState(row));
                }      
        
                return c;
            }
        };

        studentQ.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        studentQ.addMouseListener(new MouseAdapter() {
            public void mouseReleased(MouseEvent e) {
                JTable target = (JTable)e.getSource();
                int row = target.getSelectedRow();
                // System.out.println(row);
                if(row == selected_row){
                    AddButton.setEnabled(true);
                    RemoveButton.setEnabled(false);
                    Pause.setEnabled(false);
                    UnPause.setEnabled(false);
                    studentQ.clearSelection();
                    selected_row = -1;
                }else{
                    selected_row = row;
                    // select one row!
                    AddButton.setEnabled(false);
                    RemoveButton.setEnabled(true);
                    if(CustomQueue.GetEntryByIndex(row).getCurrentState() == 1) {
                        // If unpaused, enable only pause button
                        Pause.setEnabled(true);
                        UnPause.setEnabled(false);
                    } else {
                        UnPause.setEnabled(true);
                        Pause.setEnabled(false);
                    }
                }
            }
        });

        // studentQ.addFocusListener(focus_handler);

        // FIX: after click the row, there is no other way to cancel selection. MouseEvent is better!
        // studentQ.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        //     @Override
        //     public void valueChanged(ListSelectionEvent listSelectionEvent) {
        //         int selInd = studentQ.getSelectedRow();
        //         if(selected_row == selInd){
        //             // select again --> cancel

        //         }else if(selected_row != selInd){
        //             selected_row = selInd;
        //             // select one row!
        //             AddButton.setEnabled(false);
        //             RemoveButton.setEnabled(true);
        //             if(CustomQueue.GetEntryByIndex(selInd).getCurrentState() == 1) {
        //                 // If unpaused, enable only pause button
        //                 Pause.setEnabled(true);
        //                 UnPause.setEnabled(false);
        //             } else {
        //                 UnPause.setEnabled(true);
        //                 Pause.setEnabled(false);
        //             }
        //         }

        //     }
        // });
        
        // FIX: this part has some color display issue when selecting the row, use prepareRender instead
        // Add color to rows during pause and unpause operations
        // studentQ.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
        //     @Override
        //     public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        //         final Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

        //         c.setBackground(((GUITableModel)table.getModel()).updateState(row));
        //         return c;
        //     }
        // });

        JScrollPane sp = new JScrollPane(studentQ);
        sp.setBorder (BorderFactory.createTitledBorder (BorderFactory.createEtchedBorder (),
                                                            "Student Queue",
                                                            TitledBorder.CENTER,
                                                            TitledBorder.TOP));
        sp.setBackground(new Color(244,244,244));
        Menu.add(sp);

        /* message box */
        messageBox = new JLabel();
        // messageBox.setText();
        messageBox.setBackground(Color.green);
        Menu.add(messageBox);

        AddButton.setEnabled(true);
        RemoveButton.setEnabled(false);
        Pause.setEnabled(false);
        UnPause.setEnabled(false);

        /* set frame attributes */
        frame.add(Menu);
        frame.setBounds(0, 0, 500, 600); // set size
        frame.setVisible(true);

        check_queue_empty();
    }

    private class AddListener implements ActionListener {
        @Override
        public void actionPerformed(final ActionEvent ae) {
            // String str = JOptionPane.showInputDialog("What is your name?");
            final JTextField nameField = new JTextField(15);
            final JTextField mailField = new JTextField(15);
            final JTextField pwdField = new JTextField(15);

            final JPanel myPanel = new JPanel();
            myPanel.setLayout(new GridLayout(3,1));

            myPanel.add(new JLabel("name:"));
            myPanel.add(nameField);

            myPanel.add(new JLabel("email:"));
            myPanel.add(mailField);

            myPanel.add(new JLabel("password:"));
            myPanel.add(pwdField);

            final int result = JOptionPane.showConfirmDialog(null,
                    myPanel,
                    "Add a student", JOptionPane.OK_CANCEL_OPTION);
            // Object[] options = { "OK", "CANCEL" };
            // int result = JOptionPane.showOptionDialog(null, "Click OK to continue", "Warning",
            //  JOptionPane.DEFAULT_OPTION, JOptionPane.WARNING_MESSAGE,
            //  null, options, options[0]);

            if (result == JOptionPane.OK_OPTION) {
                System.out.println("add");
                String mail = mailField.getText();
                String name = nameField.getText();
                String password = pwdField.getText();
                // TODO: check if its an empty input
                if(mail.isEmpty() || name.isEmpty() || password.isEmpty()){// not allowed
                    // Border border = BorderFactory.createLineBorder(Color.BLUE, 5);
                    // nameField.setBorder(border);
                    // System.out.println("Failure: one of the field if empty.");
                    return;
                }
                boolean addOpStatus = CustomQueue.addStudent(nameField.getText(), mail, pwdField.getText());
                if(!addOpStatus){ // TODO: modify this
                    // Prompt for duplicate email. Get the entries again
                    show_message("Add a student " + name+ " failed. Duplicated email address.", Color.red.darker());
                }else{//success
                    // Display success on the dialog box in Green and close the window after 2-3 seconds.
                    // refreshTable();
                    ((GUITableModel)studentQ.getModel()).addRow();
                    studentQ.clearSelection();
                    show_message("Add a student " + name, Color.green.darker());
                }
            } else if(result == JOptionPane.CANCEL_OPTION) {

            }
        }
    }

    private class RemoveListener implements ActionListener {
        @Override
        public void actionPerformed(final ActionEvent ae) {
            JTextField pwdField = new JTextField(25);
            pwdField.setMaximumSize( pwdField.getPreferredSize() );
    
            final JPanel myPanel = new JPanel();
            myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
            myPanel.add(new JLabel("Enter password to confirm"));
            myPanel.add(new JLabel(" "));
            myPanel.add(pwdField);

            int r = studentQ.getSelectedRow();
            String name = (String)studentQ.getValueAt(r, 1);
            int result = JOptionPane.showConfirmDialog(null,
                    myPanel,
                    "You are removing: "+name, JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String pwd = pwdField.getText();
                if(pwd == ""){//TODO: check password
                    // fail
                }else{// success
                    CustomQueue.deleteStudent(r, "");
                    ((GUITableModel)studentQ.getModel()).remove(r);
                    RemoveButton.setEnabled(false);
                    Pause.setEnabled(false);
                    UnPause.setEnabled(false);
                    AddButton.setEnabled(true);
                    studentQ.clearSelection();
                    if(studentQ.getRowCount() == 0){
                        check_queue_empty();
                    }else{
                        show_message("Remove a student " + name, Color.green.darker());
                    }
                }
            }
            /* clear selected row */
            selected_row = -1;
        }
    }

    private class PauseListener implements ActionListener {
        @Override
        public void actionPerformed(final ActionEvent ae) {
            JTextField pwdField = new JTextField(25);
            pwdField.setMaximumSize( pwdField.getPreferredSize() );
    
            final JPanel myPanel = new JPanel();
            myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
            myPanel.add(new JLabel("Enter password to confirm"));
            myPanel.add(new JLabel(" "));
            myPanel.add(pwdField);

            int row = studentQ.getSelectedRow();
            String name = (String)studentQ.getValueAt(row, 1);

            int result = JOptionPane.showConfirmDialog(null,
                    myPanel,
                    "You are pausing: "+name, JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String pwd = pwdField.getText();
                if(pwd.equals("")){// TODO: password check

                }else{// pause element
                    // Pause button is enabled only for Unpaused entries.
                    // No need to validate the state again

                    CustomQueue.GetEntryByIndex(row).setCurrentState(0);
                    // ((GUITableModel)studentQ.getModel()).setRowColour(row);
                    AddButton.setEnabled(true);
                    Pause.setEnabled(false);
                    UnPause.setEnabled(false);
                    RemoveButton.setEnabled(false);
                    studentQ.clearSelection();
                    show_message("Pause " + name, Color.green.darker());
                }
            }
            /* clear selected row */
            selected_row = -1;
        }
    }

    private class UnpauseListener implements ActionListener {
        @Override
        public void actionPerformed(final ActionEvent ae) {
            JTextField pwdField = new JTextField(25);
            pwdField.setMaximumSize( pwdField.getPreferredSize() );
    
            final JPanel myPanel = new JPanel();
            myPanel.setLayout(new BoxLayout(myPanel, BoxLayout.Y_AXIS));
            myPanel.add(new JLabel("Enter password to confirm"));
            myPanel.add(new JLabel(" "));
            myPanel.add(pwdField);

            int row = studentQ.getSelectedRow();
            String name = (String)studentQ.getValueAt(row, 1);

            int result = JOptionPane.showConfirmDialog(null,
                    myPanel,
                    "You are unpausing: "+name, JOptionPane.OK_CANCEL_OPTION);
            if (result == JOptionPane.OK_OPTION) {
                String pwd = pwdField.getText();
                if(pwd == ""){// password check

                }else{// unpause
                    // CustomQueue.getAllEntries().get(row).setCurrentState(1);
                    CustomQueue.GetEntryByIndex(row).setCurrentState(1);
                    // ((GUITableModel)studentQ.getModel()).setRowColour(row);
                    AddButton.setEnabled(true);
                    Pause.setEnabled(false);
                    UnPause.setEnabled(false);
                    RemoveButton.setEnabled(false);
                    studentQ.clearSelection();
                    show_message("Unpause student " + name, Color.green.darker());
                }
            }

            /* clear selected row */
            selected_row = -1;
        }
    }
}
