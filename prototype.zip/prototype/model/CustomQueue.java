package com.gui.prototype.model;

import com.gui.prototype.model.Student;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;

public class CustomQueue {


        public static ArrayList<Student> studentList = new ArrayList<>();

        // ===========================================Add an Entry=====================================================
        // Note: For this project purpose, we refer queue to ArrayList.. Not data structure "Queue".
        //To authenticate the email, a Hash Set  has been used. It contains email IDs of all the people in the queue.
        // When adding a new entry, it checks if the email ID provided is already in the set, and if it is present, the
        // entry cannot be added. Else, the new entry will be added to the queue and email will be added to the set.
        // Once the entry is deleted, the corresponding email will also be deleted from the set.

        protected static HashSet<String> emailSet = new HashSet<String>();

        public static boolean addStudent(String name, String email, String password) {
                Student newEntry = new Student(name, email);
                if (emailSet.contains(email)) {
                        return false;
                } else {
                        emailSet.add(email);
                        newEntry.setCurrentState(1);
                        newEntry.setSessionPassword(password);
                        studentList.add(newEntry);
                        return true;
                }
        }

        // ========================================Set the password to that user=====================================
        // Set the password to the new entry after successfully adding to the queue. Set it to the new entry that was
        // just added to the queue.
        // If the entry was not added to the queue, setPwd should not be called. This needs to be taken care on the
        // UI part, whether to call setPwd or not.
        public void setPwd(String passWord) {
                Student s = studentList.get(studentList.size() - 1);
                s.setSessionPassword(passWord);
        }

        // =======================================Delete an Entry==================================================
        // ArrayList.remove(index) removes the element at that index and shifts the subsequent elements to the left.
        // While removing the entry, the corresponding email is also deleted from the hash set.

        public static boolean deleteStudent(int indexNum, String password) {
                // Password checker to be added in future.

                if (indexNum < studentList.size()) {
                        Student s = studentList.get(indexNum);
                        emailSet.remove(s.getEmail());
                        studentList.remove(s);
                        return true;
                }
                return false;
        }


        // ==============================Method to print out all the entries====================================
        // For now, I'm just printing all the entries along with their indices in the list.
        // Need to discuss how to push these entries on to UI.
        public static ArrayList<Student> getAllEntries() {
                for (int i = 0; i < studentList.size(); i++) {
                        // System.out.println(i + " " + studentList.get(i).getName());
                        //Pair<String, Integer> retVal = new Pair<>();
                }
                return studentList;


        }

        public static Student GetEntryByIndex(int i){
                return studentList.get(i);
        }
        // =====================================================================================================

        // Pause
//        ResultSet pauseStudent(int indexNum, String password) {
//
//        }
//
//        // Unpause
//        ResultSet unpauseStudent(int indexNum) {
//
//        }


        /*ArrayList<Student> studentList;
        // Add
        void addStudent(String name, String email, String password) {

        }
        // Delete
        void deleteStudent(int indexNum, String password) {

        } */

        // Pause
        boolean pauseStudent(int indexNum, String password) {
            //Password validation will be added later.

            if (indexNum < studentList.size()){
                //Student pauseEntry = studentList.get(indexNum);
                studentList.get(indexNum).setCurrentState(0);
                return true;
            }
            else
                return false;
        }

        // Unpause
        boolean unpauseStudent(int indexNum) {
            if (indexNum < studentList.size()){
                //Student unpauseEntry = studentList.get(indexNum);
                studentList.get(indexNum).setCurrentState(1);
                return true;
            }
            else
                return false;

        }
}
