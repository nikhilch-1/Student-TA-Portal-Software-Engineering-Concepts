package com.gui.prototype.model;

import javax.swing.table.AbstractTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class GUITableModel extends AbstractTableModel {
    public String[] Colname = { "No", "Name" };
    ArrayList<Student> studentList;

    public GUITableModel(ArrayList<Student> s) {
        this.studentList = s;
    }

    public int getColumnCount() {
        return 2;
    }

    public int getRowCount() {
        return studentList.size();
    }

    public String getColumnName(int col) {// return the name of each col
        return Colname[col];
    }

    public Object getValueAt(int rowInd, int colInd) {
        switch (colInd) {
            case 0:
                return rowInd+1;
            case 1:
                return studentList.get(rowInd).getName(); 
            default:
                // not reached
                return null;
        }
        
    }

    public void addRow() {
        int size = getRowCount();
        // studentList = CustomQueue.getAllEntries();
        fireTableRowsInserted(size, size);
    }

    public void remove(int ind) {
        //if(studentList.contains(ind)) {
        //    int index = studentList.indexOf(ind);
        // studentList = CustomQueue.getAllEntries();
        fireTableRowsDeleted(ind, ind);
        //}
    }

    public Color GetState(int index) {
        // studentList = CustomQueue.getAllEntries();
        int state = studentList.get(index).getCurrentState();

        if(state == 1) {
            return Color.WHITE;
        } else {
            return Color.LIGHT_GRAY;
        }
    }

    public void setRowColour(int ind) {
        System.out.println("update "+ ind);
        fireTableRowsUpdated(ind, ind);
    }

}